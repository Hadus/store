import main from './main.vue';
export default main;
