/*
 * @Author: liuhuitao
 * @Date: 2019-08-09 14:07:09
 * @Last Modified by:
 * @Last Modified time: 2019-08-09 14:53:32
 * @description: dialog 二次封住
 * @example: <mti-dialog :show.sync="addOrgNatureVisible" :width="'660px'" :title="'新增组织性质'" >显示内容</mti-dialog>
 */
import mtiDialog from './main.vue';
export default mtiDialog;
