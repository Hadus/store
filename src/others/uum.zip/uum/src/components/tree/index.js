import mtiTree from './tree.vue';
export default mtiTree;
